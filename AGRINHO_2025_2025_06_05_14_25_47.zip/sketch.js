// Definindo as variáveis globais

let jardinero;
let plantas = [];
let tenperatura=10;
let totalArvores = 0;

function setup() {
  createCanvas(600, 400);
  textAlign(CENTER, CENTER);
  jardineiro = new Jardineiro(width / 2 height - 50);
} 

function draw(){
  // usando map() para a justar acor do fundo de forma mais controlada 
  let corFundo = lerpColor(color(217 ,112,26),color(219, 239, 208), map(totalArvores,0, 100, 0, 1));
background (corFundo);
mostrarInformacoes();
temperatura += 0.1;
jardineiro.altualizar();
jardineiro.mostrar();

// verificar se o jogo acabou
verificarFimDeJogo ();

plantas.forEach((arvore) => arvore.mostrar());
}
// função para mostrar as informacoes na tela 
function mostrarInformacoes () {
textSize(26);
fill(0);
  textAlign(LEFT);
text("vamos plantas arvore para diminuir a tenperatura?",10 30);
textSize (14);
fill(" white");
text("temperatura:"+ temperatura.toFixed(2),10 390);
text("arvores plantadas:" + tolalArvores,460, 390);
text("Para movimentar o personagem use as setas do teclado.",10, 60);
text("para plantar arvores use P ou espaço.",10,80);
}

     // Verificar condições de vitória ou derrota
function verificarFimDeJogo() {
  if (totalArvores > temperatura) {
    mostrarMensagemDeVitoria();
  } else if (temperatura > 50) {
    mostrarMensagemDeDerrota();
  }
}

function mostrarMensagemDeVitoria() {
  noLoop();
  textSize(32);
  fill("green");
  textAlign(CENTER);
  text("🌱 Parabéns! Você venceu! 🌱", width / 2, height / 2);
}

function mostrarMensagemDeDerrota() {
  noLoop();
  textSize(32);
  fill("red");
  textAlign(CENTER);
  text("🔥 Aquecimento global venceu! 🔥", width / 2, height / 2);
}

// Plantar árvore ao pressionar P ou espaço
function keyPressed() {
  if (key === ' ' || key === 'p' || key === 'P') {
    let arvore = new Arvore(jardineiro.x, jardineiro.y);
    plantas.push(arvore);
    totalArvores++;
    temperatura -= 3;
    if (temperatura < 0) temperatura = 0;
  }
}

// Classe Jardineiro com emoji
class Jardineiro {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.velocidade = 5;
  }

  atualizar() {
    if (keyIsDown(LEFT_ARROW)) this.x -= this.velocidade;
    if (keyIsDown(RIGHT_ARROW)) this.x += this.velocidade;
    if (keyIsDown(UP_ARROW)) this.y -= this.velocidade;
    if (keyIsDown(DOWN_ARROW)) this.y += this.velocidade;
  }

  mostrar() {
    textSize(32);
    textAlign(CENTER, CENTER);
    text("👩‍🌾", this.x, this.y);
  }
}

// Classe Árvore com emoji
class Arvore {
  constructor(x, y) {
    this.x = x;
    this.y = y;
  }

  mostrar() {
    textSize(24);
    textAlign(CENTER, CENTER);
    text("🌳", this.x, this.y);
  }
}